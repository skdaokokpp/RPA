import gc
import time

import pandas as pd
from DrissionPage._configs.chromium_options import ChromiumOptions
from DrissionPage._functions.settings import Settings
from DrissionPage._pages.chromium_page import ChromiumPage
# from DrissionPage._units.actions import Actions
from time import sleep

class LiveArt():
    def __init__(self,url,miyue,l,sleep_time,know_point):
        self.url = url
        self.miyue = miyue
        self.l = l
        self.sleep_time = sleep_time
        self.know_point = know_point
    def Read_Answer(self,path):
        df = pd.read_excel(path)
        return df

    def Answer_Question(self,tab, l):
        tab.set.activate()
        if 'guess-artist' in tab.url:
            answer_path = './Answer-artist.xlsx'
        elif 'predict-art-price' in tab.url:
            answer_path = './Answer-price.xlsx'
        elif 'artist-market-value' in tab.url:
            answer_path = './Answer-market.xlsx'
        else:
            print("没有找到相对应的答案文件，请检查！！！！")
            return 0
        df = self.Read_Answer(path=answer_path)['答案']
        if tab.wait.ele_displayed(
                '@class=flex-grow bg-black font-poppins font-medium text-white w-full rounded-full px-12 py-5',
                timeout=15):
            print("来了")
        else:
            tab.close()
            return 0
        start_btn = tab.ele(
            '@class=flex-grow bg-black font-poppins font-medium text-white w-full rounded-full px-12 py-5')

        start_btn.wait.displayed()
        start_btn.wait.enabled()
        start_btn.wait.stop_moving()
        l.acquire()
        start_btn.click()
        l.release()
        while True:
            if tab.wait.ele_displayed(
                    '@class=flex-grow rounded-3xl bg-black px-4 py-2 font-poppins font-medium text-white', timeout=6):
                select_btns = tab.eles(
                    '@class=flex-grow rounded-3xl bg-black px-4 py-2 font-poppins font-medium text-white')
                for answer in df:
                    if answer in select_btns[0].text:
                        select_btns[0].wait.displayed()
                        select_btns[0].wait.enabled()
                        tab.wait(2)
                        try:
                            print(answer, select_btns[0].text, select_btns[1].text)
                            select_btns[0].click()
                            if select_btns[0].wait.deleted(timeout=4):
                                print("yes")
                                break
                            else:
                                continue
                        except Exception as e:
                            break
                    elif answer in select_btns[1].text:

                        select_btns[1].wait.displayed()
                        select_btns[1].wait.enabled()
                        tab.wait(2)
                        try:
                            print(answer, select_btns[0].text, select_btns[1].text)
                            select_btns[1].click()

                            if select_btns[1].wait.deleted(timeout=4):
                                print("yes")
                                break
                            else:
                                continue
                        except Exception as e:
                            break
                    else:

                        continue
                continue
            elif tab.wait.ele_displayed(
                    '@@class=flex-grow rounded-3xl px-4 py-2 font-poppins font-medium w-full border border-black bg-white text-black@@text()=Review your answers',
                    timeout=6):
                print("答题完成")
                tab.close()
                return "success"
            else:
                tab.refresh()
                tab.wait.load_start()
                try:
                    start_btn = tab.ele(
                        '@class=flex-grow bg-black font-poppins font-medium text-white w-full rounded-full px-12 py-5')
                    start_btn.wait.displayed()
                    start_btn.wait.enabled()
                    l.acquire()
                    start_btn.click()
                    l.release()
                except:
                    return 0

                continue

    def connect_network(self,tab):
        tab.wait.eles_loaded(['tag:button', 'tag:div'])
        next_btn = tab.ele('@@data-testid=page-container-footer-next@@text()=下一步')
        next_btn.wait.not_covered()
        next_btn.wait.displayed()
        next_btn.wait.enabled()
        next_btn.click()

        if tab.wait.ele_displayed('@@data-testid=page-container-footer-next@@text()=确认'):
            next_btn = tab.ele('@@data-testid=page-container-footer-next@@text()=确认')
            next_btn.wait.not_covered()
            next_btn.wait.displayed()
            next_btn.wait.enabled()
            next_btn.click()
            tab.close()
            return "success"

    def run_main(self):
        page = None
        try:
            sleep(self.sleep_time)
            options = ChromiumOptions()
            options.auto_port()
            options.add_extension('./MetaMask')
            Settings.raise_when_ele_not_found = False
            Settings.raise_when_wait_failed = False
            Settings.raise_when_click_failed = True
            options.set_argument('--start-maximized')
            options.set_retry(times=10, interval=10)
            options.set_timeouts(base=30)
            page = ChromiumPage(addr_or_opts=options)


            hu_path = "migkllbofbocpaneogpaklideedjjioh"
            Hu_tab = page.new_tab(url=f'chrome-extension://{hu_path}/home.html#onboarding/welcome')
            return_new = {'know': self.know_point, 'if_success': True}
            main_tab = page.new_tab(self.url)
            from Scripts_model import Dao_Wallet
            result_dao = Dao_Wallet(tab=Hu_tab, miyue=self.miyue)

            if result_dao:

                for tab in page.get_tabs(title="MetaMask"):
                    tab.close()
                if main_tab.wait.ele_displayed(
                        '@@class=h-12 w-[240px] whitespace-nowrap rounded-[80px] px-4 py-3 font-poppins text-base font-semibold text-white@@text()=Connect Wallet',
                        timeout=20):
                    connect_btn = main_tab.ele(
                        '@@class=h-12 w-[240px] whitespace-nowrap rounded-[80px] px-4 py-3 font-poppins text-base font-semibold text-white@@text()=Connect Wallet')

                    connect_btn.wait.displayed()
                    connect_btn.wait.enabled()
                    connect_btn.wait.stop_moving()
                    connect_btn.click()
                else:
                    print("需要人机验证")
                    page.clear_cache()
                    page.quit()
                    return "need_certified"
                if main_tab.wait.ele_displayed('@class=iekbcc0 ju367v6p _1vwt0cg2 ju367v7a ju367v7v'):
                    metamask_btn = main_tab.ele('@class=iekbcc0 ju367v6p _1vwt0cg2 ju367v7a ju367v7v').ele(
                        '@data-testid=rk-wallet-option-io.metamask')
                    metamask_btn.wait.displayed()
                    metamask_btn.wait.enabled()
                    main_tab.wait(2,3)
                    metamask_btn.click()
                    from Scripts_model import Wait_New_Tab
                    connect_tab = Wait_New_Tab(page=page, new_url=f'chrome-extension://{hu_path}')
                    if connect_tab:

                        result_cnt = self.connect_network(tab=connect_tab)
                        if result_cnt:
                            l = self.l
                            print("连接成功！")
                            # 获取第一大任务板块
                            # task_lists = main_tab.ele('@class=grid grid-cols-1 gap-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4').eles('@class=relative flex shrink-0 flex-col items-start font-manrope text-white')
                            sleep(4)
                            answer_tab1 = main_tab.ele(
                                '@@class=text-3xl font-semibold leading-8 text-black@@text()=Guess the Creator of the Artwork').click.for_new_tab()
                            self.Answer_Question(tab=answer_tab1, l=l)
                            answer_tab2 = main_tab.ele(
                                '@@class=text-3xl font-semibold leading-8 text-black@@text()=Guess the Current Artwork Price').click.for_new_tab()
                            self.Answer_Question(tab=answer_tab2, l=l)
                            answer_tab3 = main_tab.ele(
                                '@@class=text-3xl font-semibold leading-8 text-black@@text()=Guess the Artist’s Market Size').click.for_new_tab()
                            self.Answer_Question(tab=answer_tab3, l=l)
                            page.clear_cache()
                            page.quit()
                            return return_new
            page.quit()
        except Exception as e:
            print(e)
            if page:
                page.quit()
            return False




    def Save_excel(self,path, df):
        df.to_excel(path, index=False)

    def Read_url(self,path):
        df = pd.read_excel(path)
        return df['地址']

    def Read_Hu(self,path):
        df = pd.read_excel(path)
        return df['密钥']