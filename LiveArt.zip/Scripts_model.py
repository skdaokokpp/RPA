import os
import random
import shutil
import time

#import ffmpeg
import pandas as pd
from DrissionPage._functions.keys import Keys
from DrissionPage._units.actions import Actions


# import whisper
# from pydub import AudioSegment




#过recaptch人机验证模块
# def transcribe_audio(src_path):
#     try:
#         audio_file_path = 'one.mp3'
#         audio = AudioSegment.from_file(src_path)
#         audio.export(audio_file_path,format='mp3')
#     except Exception as e:
#         print(e)
#     # os.chmod(audio_file_path, 0o777)
#     model = whisper.load_model('base')  # 可以选择不同的模型大小，如 "tiny", "small", "medium", "large"
#     result = model.transcribe(src_path)
#     if result:
#         os.remove(audio_file_path)
#         os.remove(src_path)
#     return result["text"]
# def Pass_robort(tab,page):
#     if tab.wait.ele_displayed('@title=reCAPTCHA'):
#         # 获取
#         recapt_frame = tab.get_frame('@title=reCAPTCHA')
#
#         if recapt_frame.wait.ele_displayed('@class=recaptcha-checkbox-border'):
#             recapt_btn = recapt_frame.ele('@class=recaptcha-checkbox-border')
#             recapt_btn.wait.displayed()
#             recapt_btn.wait.enabled()
#             # Actions(tab).move_to(recapt_btn).click(recapt_btn)
#             recapt_btn.click()
#
#             if tab.wait.ele_displayed('@sandbox=allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation'):
#                 print(12)
#                 tab.wait(2, 3)
#                 re_main = tab.get_frames('@sandbox=allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox allow-storage-access-by-user-activation')[1]
#                 re_main.listen.start('api2/payload?')
#                 # l.acquire()
#                 audio_btn = re_main.ele('@class=rc-button goog-inline-block rc-button-audio')
#                 audio_btn.wait.enabled()
#                 while True:
#                     try:
#                         audio_btn.click()
#                     except:
#                         print("网络错误")
#                         return "error"
#                     re = re_main.listen.wait(timeout=20)
#                     if re:
#                         print(re.url)
#                         resutl_down = page.download(re.url)
#                         print(resutl_down)
#                         if resutl_down[0] == 'success':
#                             result_text = transcribe_audio(src_path='./payload')
#                             if result_text:
#                                 result_input = re_main.ele('@id=audio-response')
#                                 result_input.input(result_text)
#                                 re_main.wait(1, 2)
#
#                                 submit_btn = re_main.ele('@id=recaptcha-verify-button')
#                                 submit_btn.wait.displayed()
#                                 submit_btn.wait.enabled()
#                                 submit_btn.run_js('this.click();')
#                                 # l.release()
#                                 break
#                     else:
#                         continue
#创建谷歌浏览器配置文件
def Creat_User_Data_Path(src_path,chrome_path):
    src_path = os.path.abspath(src_path)
    target_path = os.path.abspath(chrome_path)
    if os.path.exists(src_path):
        # 修改文件权限
        os.chmod(src_path, 0o777)
    else:
        print("文件不存在")
    if not os.path.exists(target_path):
        # 如果目标路径不存在原文件夹的话就创建
        os.makedirs(target_path)

    if os.path.exists(src_path):
        # 如果目标路径存在原文件夹的话就先删除
        shutil.rmtree(target_path)

    shutil.copytree(src_path, target_path)
#读取excel
def Read_excel(path):
    df = pd.read_excel(path)
    return df
#保存excel
def Save_excel(df, path):
    df.to_excel(path, index=False)
#登录推特模块
def Login_Twitter(tab, twitter_pwd):
    print(tab.url, tab.title)
    tab.wait(2, 3)
    tab.wait.eles_loaded(['tag:div', 'tag:span'])

    # tab.wait.ele_displayed('@@class=css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3@@text()=手机号码、邮件地址或用户名')
    login_js = ("""
            var token = '%s';
            var currentDomain = '.' + window.location.hostname.split('.').slice(-2).join('.');
            document.cookie = `auth_token=${token};domain=${currentDomain};path=/;max-age=25920000;Secure`;
            window.location.reload();
            var expirationTime = new Date();
            expirationTime.setFullYear(expirationTime.getFullYear() + 1); // expires in 1 year
            document.cookie = `auth_token=${token.replace('"', '')};domain=x.com;path=/;expires=${expirationTime.toUTCString()};Secure`;
            window.location.replace('https://x.com');
        """ % (twitter_pwd))
    tab.run_js(login_js)
    tab.wait.load_start()
    tab.wait.doc_loaded()
    tab.wait.eles_loaded(['tag:span', 'tag:div', 'tag:button'])
    if tab.wait.ele_displayed('@data-testid=ScrollSnap-List', timeout=15):
        print("推特登录完毕")
        # tab.close()
        return "success"
    else:
        print("推特登录失败")
        # tab.close()
        return "next_twitter"
#等待新标签页模块
from DrissionPage import ChromiumPage
def Wait_New_Tab(page,new_url)->ChromiumPage:
    jishi = 0
    time.sleep(3)
    # 等待小狐狸登录页面出来
    while True:
        if jishi == 7:
            return
        try:
            for one_tab in page.tab_ids:
                if jishi == 7:
                    break
                if new_url in str(page.get_tab(one_tab).url):
                    network_tab = page.get_tab(one_tab)
                    return network_tab
        except Exception as e:
            print(e)
            continue
        print("等待新标签页中----")
        time.sleep(3)
        jishi += 1

def rand_word():
    a_low = chr(random.randint(97,121))
    a_up = chr(random.randint(65,90))
    return a_low,a_up






def creat_Tw(tab,page,email):
    creat_btn = tab.ele('tag:span@@class=css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3@@text()=创建账号')
    creat_btn.wait.enabled()
    creat_btn.click()
    change_email = tab.ele('tag:span@@class=css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-poiln3@@text()=改用电子邮件',timeout=20)

    if change_email:
        change_email.wait.enabled()
        change_email.click()
    name = ''
    #随机名字
    for a in range(0,5):
        a_low,a_up = rand_word()
        # 输入名字
        tab.ele('tag:input@@autocapitalize=sentences@@name=name').input(a_up)
        tab.ele('tag:input@@autocapitalize=sentences@@name=name').input(a_low)

    #输入电子邮件
    emaik_input = tab.ele('tag:input@@autocapitalize=sentences@@name=email')
    # tab_action = Actions(tab)
    # tab_action.move_to(emaik_input)
    # tab_action.click()
    # tab.actions.key_down(Keys.CTRL)
    # tab.actions.type('v')
    # tab.actions.key_up(Keys.CTRL)
    emaik_input.input(email)
    #选择月份
    month = tab.ele('tag:select@aria-labelledby=SELECTOR_1_LABEL')
    # month = options[0]
    month_count = random.randint(1,12)
    month.select.by_value(month_count)
    tab.wait(2)
    #选择日
    # day = options[1]
    day = tab.ele('tag:select@aria-labelledby=SELECTOR_2_LABEL')
    day_count = random.randint(1, 28)
    day.select.by_value(day_count)
    tab.wait(2)
    #选择年
    # year = options[2]
    year = tab.ele('tag:select@aria-labelledby=SELECTOR_3_LABEL')
    year_count = random.randint(1980,2003)
    year.select.by_value(year_count)
    tab.wait(2)
    #点击下一步
    next_btn = tab.ele('tag:button@@data-testid=ocfSignupNextLink')
    next_btn.wait.enabled()
    next_btn.click()
    if tab.wait.ele_displayed('tag:button@@data-testid=ocfSettingsListNextButton'):
        next_btn = tab.ele('tag:button@@data-testid=ocfSettingsListNextButton')
        next_btn.wait.enabled()
        next_btn.click()

def get_code(tab):
    tab.set.activate()
    #如果有确认
    okbtn = tab.ele('tag:button@@class=swal2-confirm styled@@text()=OK')
    if okbtn:
        okbtn.click()
    #等待验证码
    x_email = tab.ele('tag:tbody@id=maillist',timeout=40).ele('tag:td@text()=X <info@x.com>',timeout=40)
    if x_email:
        code = tab.ele('tag:tbody@id=maillist').eles('tag:td')[1].text.split(' ')[0]
        print(code)
        return code
def get_email(tab,page):
    #点击复制邮箱到粘贴板
    tab.ele('tag:button@class=myButton').click()
    #获取邮箱
    text = tab.ele('tag:div@class=swal2-content').text
    if text:
        return text.split('：')[1]
    else:
        return False

def creat_twitter(page):
    try:
        google_email_tab = page.new_tab('https://gmail.pm/')
        # page.handle_alert(accept=True, send='1432495-e8ff7d8d')
        twitter_tab = page.new_tab('https://x.com/?lang=zh')
        email = get_email(google_email_tab, page)
        if not email:
            return False
        twitter_tab.set.NoneElement_value(value=False)
        creat_Tw(tab=twitter_tab,page=page,email=email)
        # #
        code_input = twitter_tab.ele('tag:input@name=verfication_code',timeout=120)
        if not code_input:
            return False
        #获取验证码
        print('创建')
        code = get_code(tab=google_email_tab)
        twitter_tab.set.activate()

        if code_input:
            code_input.input(code)
            #点击下一步
            next_btn = twitter_tab.ele('tag:button@class=css-175oi2r r-sdzlij r-1phboty r-rs99b7 r-lrvibr r-19yznuf r-64el8z r-1fkl15p r-1loqt21 r-o7ynqc r-6416eg r-1ny4l3l')
            next_btn.wait.enabled()
            next_btn.click()
            #输入密码
            pwd_input = twitter_tab.ele('tag:input@@autocapitalize=sentences@@name=password')
            Actions(twitter_tab).move_to(pwd_input).input('Aabb123456!')
            # pwd_input.input()
            twitter_tab.wait(1)
            #点击注册
            login_btn = twitter_tab.ele('tag:button@data-testid=LoginForm_Login_Button')
            login_btn.wait.enabled()
            login_btn.click()
            twitter_tab.wait(1)
            #暂时跳过
            pass_btn = twitter_tab.ele('tag:button@data-testid=ocfSelectAvatarSkipForNowButton')
            pass_btn.wait.enabled()
            pass_btn.click()
            # 暂时跳过2
            pass_btn2 = twitter_tab.ele('tag:button@data-testid=ocfEnterUsernameSkipButton')
            pass_btn2.wait.enabled()
            pass_btn2.click()
        twitter_tab.wait(5)

        # if twitter_tab.wait.ele_displayed('@data-testid=ScrollSnap-List', timeout=500):
        print('创建完毕')
        token_twitter = twitter_tab.cookies().as_dict().get('auth_token')
        return token_twitter
    except Exception as e:
        print(e)
        return False
def Connect_hu(tab,str):
    if str == "确认":
        if tab.wait.ele_displayed('tag:button@aria-label=向下滚动',timeout=5):
            tab.ele('tag:button@aria-label=向下滚动').click()
            print('滚动')
        confir_btn = tab.ele('tag:button@@data-testid=confirm-footer-button@@text()=确认')
        confir_btn.wait.enabled()
        confir_btn.scroll.to_see()
        confir_btn.click(True)

        # tab.close()
    elif str == "连接":
        tab.ele('tag:button@@data-testid=confirm-btn@@text()=连接').click()

def openai(question):
    import requests
    import json
    url = 'https://api.mixrai.com/v1/chat/completions'
    api_key = 'sk-P6qW4T2BENLykgoS842aD6FbAb8c426d9b160d039a076a48'
    pay_load = json.dumps({"model":"gpt-3.5-turbo","messages":[{"role":"user","content":f"{question}"}]})
    headers = {
        "Accept":"application/json",
        "Authorization":api_key,
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Content-Type":"application/json",
    }
    response = requests.request(method="POST",url=url,headers=headers,data=pay_load)
    position = response.text.find('content')
    after_long = response[position:]
    before_position = after_long.find('":"')
    after_position = after_long.find('。"}')
    answer_text = after_long[before_position + 3:after_position]
    return answer_text
def OKX_Wallet(tab,miyue):
    dao_btn = tab.ele('tag:button@class=okui-btn btn-xl btn-outline-primary block')
    dao_btn.wait.displayed()
    dao_btn.wait.clickable()
    dao_btn.click()
    #助记词或私钥
    miyue_btn = tab.ele('tag:div@class=_wallet-list__item_d9txs_4 _wallet-list__item__hover_d9txs_8 _wallet-list__cell_d9txs_23 _listCell_q2vqq_29')
    miyue_btn.wait.displayed()
    miyue_btn.click()
    #选择私钥
    primary_btn = tab.ele('tag:div@@class=okui-tabs-pane okui-tabs-pane-sm okui-tabs-pane-grey okui-tabs-pane-segmented@@data-e2e-okd-tabs-pane=2')
    primary_btn.wait.displayed()
    primary_btn.wait.enabled()
    primary_btn.click()
    #填入私钥
    primary_text = tab.ele('tag:textarea@class=okui-input-input input-textarea ta _input_o5han_7')
    primary_text.wait.displayed()
    primary_text.wait.has_rect()
    primary_text.input(miyue)
    #确定
    confir_btn = tab.ele('tag:button@class=okui-btn btn-lg btn-fill-highlight block')
    confir_btn.wait.displayed()
    confir_btn.wait.clickable()
    confir_btn.click()
    confir_btn_2 = tab.ele('tag:button@class=okui-btn btn-lg btn-fill-highlight block chains-choose-network-modal__confirm-button')
    confir_btn_2.wait.displayed()
    confir_btn_2.wait.clickable()
    confir_btn_2.click()
    #密码严重
    password_know = tab.ele('tag:div@@class=_typography-text_1os1p_1 _typography-text-left_1os1p_8 _typography-text-md_1os1p_25 _typography-text-default_1os1p_52 _item-title_1ybp2_45@@text()=密码验证')
    password_know.wait.displayed()
    password_know.click(True)
    #下一版
    next_btn = tab.ele('tag:button@class=okui-btn btn-lg btn-fill-highlight block')
    next_btn.wait.displayed()
    next_btn.wait.clickable()
    next_btn.click(True)
    #获取两个密码Kuang\
    pwd_inputs = tab.eles('tag:input@class=okui-input-input _passwordInput_cl85f_6')
    for pwd_input in pwd_inputs:
        pwd_input.wait.displayed()
        pwd_input.input('Qq123456')
    #确认
    confir_btn_3 = tab.ele('tag:button@class=okui-btn btn-lg btn-fill-highlight block')
    confir_btn_3.wait.displayed()
    confir_btn_3.wait.clickable()
    confir_btn_3.click(True)
    #
    tab.set.NoneElement_value(False)
    tab.ele('tag:div@class=_typography-text_1os1p_1 _typography-text-left_1os1p_8 _typography-text-md_1os1p_25 _typography-text-default_1os1p_52 _title_1xjqk_13')
    tab.close()
    return True
def Dao_Wallet(tab, miyue):
    # mm-box mm-text callout__content mm-text--body-md mm-box--color-text-default
    # 连接到自定义网络时出错。
    # span
    # check-box onboarding__terms-checkbox far fa-square
    if tab.wait.ele_displayed('@class=check-box onboarding__terms-checkbox far fa-square'):
        checkbox = tab.ele("@class=check-box onboarding__terms-checkbox far fa-square")
        checkbox.wait.not_covered(timeout=3)
        checkbox.wait.displayed()
        checkbox.wait.enabled()
        checkbox.run_js('this.click();')
        # 导入现有钱包
        daoru = tab.ele('@@data-testid=onboarding-import-wallet@@class=button btn--rounded btn-secondary')
        daoru.wait.not_covered()
        daoru.wait.enabled()
        daoru.run_js('this.click();')
        # 我同意
        i_acept = tab.ele('@data-testid=metametrics-i-agree')
        i_acept.wait.stop_moving()
        i_acept.click()
        list_miyue = miyue.split(' ')
        inputs_pwd = tab.eles('@@class=MuiInputBase-input MuiInput-input')
        confirm_btn = tab.ele('@@data-testid=import-srp-confirm')
        # 导入小狐狸密钥
        input_math = 0
        for one_miyue in list_miyue:
            if input_math == 12:
                break
            inputs_pwd[input_math].input(one_miyue)
            input_math += 1
        confirm_btn.wait.enabled()
        confirm_btn.click()
        # 设置密码
        set_pwd = tab.ele('@data-testid=create-password-new')
        confirm_pwd = tab.ele('@data-testid=create-password-confirm')
        creat_pwd_btn = tab.ele('@data-testid=create-password-import')
        set_pwd.input('aabb123456')
        confirm_pwd.input('aabb123456')
        checkbox2 = tab.ele('@data-testid=create-password-terms')
        checkbox2.run_js('this.click()')
        creat_pwd_btn.wait.enabled()
        creat_pwd_btn.click()
        if tab.wait.url_change(text='completion'):
            tab.ele('@@data-testid=onboarding-complete-done').click()
            if tab.wait.url_change(text='pin-extension'):
                tab.ele('@@data-testid=pin-extension-next').click()
                tab.wait.ele_displayed('@data-testid=pin-extension-done')
                tab.ele('@data-testid=pin-extension-done').click()
    # 解锁密码
    elif tab.wait.ele_displayed('@@class=button btn--rounded btn-default@@data-testid=unlock-submit'):
        # 输入密码
        pwd_input = tab.ele('@data-testid=unlock-password')
        pwd_input.wait.displayed()
        pwd_input.input('aabb123456')
        # 寻找submit按钮
        submit_btn = tab.ele('@class=button btn--rounded btn-default')
        submit_btn.wait.displayed()
        submit_btn.wait.enabled()
        submit_btn.run_js('this.click();')
        return False
    if tab.wait.ele_displayed(
            '@class=mm-box mm-text currency-display-component__suffix mm-text--inherit mm-box--margin-inline-start-1 mm-box--color-text-default'):
        print('导入成功')
        tab.wait(3)
        # tab.close()
        return True

    return False