import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from time import sleep
from Scripts_model import Save_excel
from task_liveart import LiveArt
from threading import Lock


#全局变量控制cid下标
cid_count = 0

def task_list(data_dfs):
    if data_dfs.empty:
        print('数据已用光了')
        return True
    #分配计数
    global cid_count
    tasks = []
    second = 0
    sleep_time = 0
    l = Lock()
    for data_df in data_dfs.values:
        if cid_count>0 and cid_count<4:
            sleep_time += 16
        else:
            sleep_time = 0

        task = LiveArt(miyue=data_df[0], url=data_df[1],l=l,sleep_time=sleep_time,know_point=cid_count)
        tasks.append(task)
        #cid下标自增1
        cid_count += 1
    #开启任务遍历任务数
    with ThreadPoolExecutor(max_workers=4) as thread_pool:
        results = []
        for task in tasks:

            future = thread_pool.submit(task.run_main)

            results.append(future)
            # sleep(6)
        for result in as_completed(results):
            if result.result():
                #获取任务窗口标识
                know_math = result.result().get('know')
                #更新cids数据信息
                data_dfs = data_dfs.drop(know_math)
                print(data_dfs)
                #地址成功数累加

                Save_excel(df=data_dfs, path='./data-sosovalue.xlsx')

                print('保存成功')
    return True



def Run_main(data_dfs,):
    # 入口给定初始url数据

    # 初始化地址完成数
     task_list(data_dfs=data_dfs)

