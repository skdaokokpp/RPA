import multiprocessing
import time
import pyautogui
from set_threads import Run_main
from Scripts_model import Read_excel
#引用任务
if __name__ == '__main__':

    data_dfs = Read_excel('./data-LiveArt.xlsx')
    #开启任务进程
    with multiprocessing.Pool(processes=1) as pool:
        result = pool.apply_async(Run_main,args=(data_dfs,))
        print(result.get())